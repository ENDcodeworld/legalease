# LegalEase - 法律援助智能助手

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![GitHub stars](https://img.shields.io/github/stars/yourusername/legalease?style=social)](https://github.com/yourusername/legalease)
[![PRs Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen.svg)](CONTRIBUTING.md)
[![Discord](https://img.shields.io/badge/chat-on%20discord-7289DA)](https://discord.gg/your-invite)

> 🎯 **使命**：让每个人都能轻松获得法律援助，降低法律咨询门槛

---

## 🌟 为什么选择 LegalEase？

| 问题 | LegalEase 的解决方案 |
|------|----------------------|
| 普通人不懂法律 | 📚 **智能问答** - 用大白话解释法律问题 |
| 找法条太麻烦 | 🔍 **一键检索** - 输入问题，自动定位相关法条 |
| 案例看不懂 | 📖 **案例解读** - 将判决书翻译成人话 |
| 请律师太贵 | 💰 **免费开源** - 自己部署，无限使用 |
| 担心AI胡编 | ⚖️ **来源可查** - 每个答案附带法条/案例原文链接 |
| 不会技术 | 🚀 **一键部署** - 支持 Docker、Vercel、本地运行 |

---

## 🚀 快速开始

### 方式一：Docker（推荐）

```bash
docker run -p 3000:3000 \
  -e OPENAI_API_KEY=your_key \
  ghcr.io/yourusername/legalease:latest
```

### 方式二：Vercel 一键部署

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/import/clone?repository-url=https%3A%2F%2Fgithub.com%2Fyourusername%2Flegalease)

### 方式三：本地运行

```bash
git clone https://github.com/yourusername/legalease.git
cd legalease
npm install
npm run dev
```

---

## 📦 功能特性

### 🎯 核心功能

- **智能法律问答**：输入民事、刑事、行政问题，AI 给出专业解答
- **法条检索**：输入关键词，快速找到相关法律法规
- **案例搜索**：查询类似案例，了解判决结果
- **文书生成**：自动生成起诉状、答辩状等法律文书模板
- **法律计算器**：诉讼费、赔偿金、工伤待遇自动计算

### 🔧 技术亮点

- **向量数据库**：使用 ChromaDB 存储法条和案例，快速语义检索
- **多模型支持**：OpenAI GPT、Claude、本地 Ollama 均可
- **RAG 架构**：确保回答基于真实法律条文，减少幻觉
- **响应式设计**：手机、平板、电脑完美适配
- **PWA 支持**：可安装为桌面应用，离线使用部分功能

---

## 🏗️ 项目结构

```
legalease/
├── app/              # Next.js 应用
│   ├── api/         # API 路由
│   ├── components/  # React 组件
│   └── lib/         # 工具函数
├── data/            # 法律数据（法条、案例）
│   ├── laws/        # 法律法规 JSON
│   └── cases/       # 典型案例 JSON
├── scripts/         # 数据处理脚本
├── docker-compose.yml
├── Dockerfile
└── README.md
```

---

## 📊 技术栈

| 技术 | 用途 |
|------|------|
| **Next.js 14** | 前端框架，App Router |
| **TypeScript** | 类型安全 |
| **Tailwind CSS** | 样式 |
| **ChromaDB** | 向量数据库 |
| **LangChain** | AI 编排 |
| **OpenAI GPT-4** | 核心 AI 模型（也支持其他） |
| **Vercel** | 部署平台 |

---

## 🤝 贡献指南

我们非常欢迎社区贡献！无论是：

- 🐛 提交 Bug 报告
- 💡 提出新功能建议
- 📝 改进文档
- 🔧 提交 Pull Request

请查看 [CONTRIBUTING.md](CONTRIBUTING.md) 了解详情。

---

## 📄 许可证

本项目基于 MIT 许可证开源 - 查看 [LICENSE](LICENSE) 文件了解详情。

---

## 🙏 致谢

- 数据来源：[国家法律法规数据库](http://www.npc.gov.cn)
- 案例来源：[中国裁判文书网](https://wenshu.court.gov.cn)
-  inspired by [Lawyer LLaMA](https://github.com/AndrewZhe/lawyer-llama)

---

## ⭐ Star 历史

- 2024-03-xx: 0 → 100 ⭐
- 2024-04-xx: 100 → 500 ⭐
- 2024-05-xx: 500 → 1000 ⭐ 🎉

**目标是下个月达到 1000 star，你确定要加入吗？**

[👉 立即 Star 支持我们](https://github.com/yourusername/legalease/stargazers)
